# LibraryProject
This is a starter Django project created for the ALX Django Learn Lab. It sets up the development environment and explores the default Django structure.
